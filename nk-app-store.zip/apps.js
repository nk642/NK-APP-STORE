const appList = document.getElementById("app-list");
let apps = JSON.parse(localStorage.getItem("apps")) || [];
apps.forEach(app => {
  const appCard = document.createElement("div");
  appCard.className = "app-card";
  appCard.innerHTML = `
    <img src="${app.image}" alt="${app.name}">
    <h3>${app.name}</h3>
    <p>${app.description}</p>
    <a href="${app.apk}" download>
      <button class="download-btn">Download</button>
    </a>
  `;
  appList.appendChild(appCard);
});