if (localStorage.getItem("adminLoggedIn") !== "true") {
  window.location.href = "login.html";
}
function uploadApp() {
  const name = document.getElementById("appName").value;
  const desc = document.getElementById("appDesc").value;
  const img = document.getElementById("appImage").value;
  const apk = document.getElementById("apkLink").value;

  if (!name || !desc || !img || !apk) {
    alert("Please fill all fields!");
    return;
  }

  const newApp = { name, description: desc, image: img, apk };
  let apps = JSON.parse(localStorage.getItem("apps")) || [];
  apps.push(newApp);
  localStorage.setItem("apps", JSON.stringify(apps));

  alert("App Uploaded Successfully!");
  document.getElementById("appName").value = "";
  document.getElementById("appDesc").value = "";
  document.getElementById("appImage").value = "";
  document.getElementById("apkLink").value = "";
}